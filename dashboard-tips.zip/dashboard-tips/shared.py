from pathlib import Path

import pandas as pd

app_dir = Path(__file__).parent
tips = pd.read_csv(app_dir / "tips.csv")
hate = pd.read_parquet(app_dir / "sampled_hate_cleaned_w_topics.parquet")